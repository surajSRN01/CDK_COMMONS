class ListType:
    
    is_premitive: bool
    class_type: None

    def __init__(self, is_premitive, class_type):
        self.is_premitive = is_premitive
        self.class_type = class_type