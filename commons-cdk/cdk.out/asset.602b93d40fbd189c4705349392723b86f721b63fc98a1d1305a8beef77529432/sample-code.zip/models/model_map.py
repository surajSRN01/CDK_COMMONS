import models.Address as Address
import models.Person as Person
import models.Models as Models
import models.OfferData as OfferData
import models.Dependent as Dependent
import models.Occupation as Occupation
import models.Car as Car



MODEL_MAP = {
    "com.ignite.model.address.Address" : Address.Address,
    "com.ignite.model.person.Person" : Person.Person,
    "com.ignite.model.models.Models": Models.Models,
    "com.ignite.model.offerData.OfferData": OfferData.OfferData,
    "com.ignite.model.dependent.Dependent" : Dependent.Dependent,
    "com.ignite.model.occupation.Occupation" : Occupation.Occupation,
    "com.ignite.model.car.Car" : Car.Car   
}


def get_model_class_by_config(config):
    return MODEL_MAP.get(config)
        