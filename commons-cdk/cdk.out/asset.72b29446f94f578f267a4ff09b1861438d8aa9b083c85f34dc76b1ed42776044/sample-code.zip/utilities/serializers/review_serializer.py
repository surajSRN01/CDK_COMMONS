# from models.Review import Review
# from utilities import transformer as transformer
# from utilities import validator as validator

# # properties for Review
# PULISHED_DATE = "published"
# PULISHED_DATE_FORMAT = "%Y-%m-%d %H:%M"
# _ID = "_id"
# RESOURCEID = "resourceId"
# OWNER = "owner"
# BRANDS = "brands"
# COUNTRY = "country"
# LANGUAGE = "language"
# TYPE = "type"
# QUEST_ID = "questId"
# STAR_RATING = "starRating"
# COMMENT = "comment"

# def serialize(source: Review):
#     review_target = Review()

#     if validator.is_nan(source):
#         return

#     transformer.copy_value({"object": source, "key": "published"},
#                            {"object": review_target, "key": PULISHED_DATE}, "date", PULISHED_DATE_FORMAT)

#     transformer.copy_value({"object": source, "key": "resourceId"},
#                            {"object": review_target, "key": RESOURCEID}, "str", None)

#     transformer.copy_value({"object": source, "key": "country"},
#                            {"object": review_target, "key": COUNTRY}, "str", None)

#     transformer.copy_value({"object": source, "key": "_id"},
#                            {"object": review_target, "key": _ID}, "str", None)

#     transformer.copy_value({"object": source, "key": "owner"},
#                            {"object": review_target, "key": OWNER}, "str", None)

#     transformer.copy_value({"object": source, "key": "language"},
#                            {"object": review_target, "key": LANGUAGE}, "str", None)

#     transformer.copy_value({"object": source, "key": "type"},
#                            {"object": review_target, "key": TYPE}, "str", None)

#     transformer.copy_value({"object": source, "key": "questId"},
#                            {"object": review_target, "key": QUEST_ID}, "str", None)

#     transformer.copy_value({"object": source, "key": "starRating"},
#                            {"object": review_target, "key": STAR_RATING}, "str", None)

#     transformer.copy_value({"object": source, "key": "comment"},
#                            {"object": review_target, "key": COMMENT}, "str", None)

#     transformer.copy_value({"object": source, "key": "brands"},
#                            {"object": review_target, "key": BRANDS}, "str", None)

#     source = review_target
#     return source