from json import JSONEncoder

from models.Person import Person
# from models.Group import Group
# from models.Review import Review
from utilities import transformer as transformer
from utilities import validator as validator
from utilities.serializers import (person_serializer, group_serializer, review_serializer)

class IgniteJsonEncoder(JSONEncoder):
    
    def default(self, source):
        
        if isinstance(source, Person):
            person_serializer.serialize(source)

        # if isinstance(source, Review):
        #     source = review_serializer.serialize(source)

        # if isinstance(source, Group):
        #     source = group_serializer.serialize(source)

        # TODO: Do we really need this, removing None|empty values    
        if validator.is_nan(source):
            return 
            
        return source.__dict__