
from aggregators.rules.aggregator_utils import rules_utils

from models.Person import Person


def serialize(person: Person):
    serialize_fullname(person)
    return person


def serialize_fullname(person: Person):

    if rules_utils.getOrDefault(person, "firstName") == None:
        if rules_utils.getOrDefault(person, "lastName") == None:
            return
        return

    fullName = {}
    fullName["firstName"] = person.firstName
    fullName["lastName"] = person.lastName
    person.fullName = fullName["firstName"]+" "+fullName["lastName"]
