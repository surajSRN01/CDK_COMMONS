from dataclasses import dataclass
import jsonpickle
from utilities import validator as validator
from models import Geolocation as Geolocation

@dataclass
class Address:

    zipCode: str
    regionName: str
    dmaName: str
    dmaCode: str
    geoLocation: Geolocation.Geolocation
    
    def __init__(self) :
        pass

    def __getitem__(self, item):
        return getattr(self, item)

    def __setitem__(self, item, value):
        REMOVE_DECIMALS = ["zipCode"]
        if item in REMOVE_DECIMALS:
            if "." in str(value):
                value=str(value).split(".")[0]
        return setattr(self, item, value)
    
    def compare(self, objectToCompare):
        # compare the selected things on Address
        for key in ["zipCode","regionName","dmaName","dmaCode"]:
            if hasattr(self, key) and hasattr(objectToCompare, key):
                if not str(self[key]).strip().casefold() == str(objectToCompare[key]).strip().casefold():
                    return False
            if not hasattr(self, key) and hasattr(objectToCompare, key):
                return False
            if hasattr(self, key) and not hasattr(objectToCompare, key):
                return False           
        return True
    
    def __hash__(self) -> int:
        return hash(jsonpickle.dumps(self.__dict__))
    
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, self.__class__) and \
            self.__dict__ == __o.__dict__
                          