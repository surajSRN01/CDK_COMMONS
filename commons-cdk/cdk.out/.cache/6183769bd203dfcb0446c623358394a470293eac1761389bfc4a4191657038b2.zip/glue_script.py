import main as flow

print("inside the glue script")
flow.main()
