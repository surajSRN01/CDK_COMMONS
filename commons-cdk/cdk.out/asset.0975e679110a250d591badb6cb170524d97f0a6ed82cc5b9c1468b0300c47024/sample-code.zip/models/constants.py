
import pymongo

model_names = {
    "Item": "com.ignite.model.item.Item",
    "Address": "com.ignite.model.address.Address",
    "Models": "com.ignite.model.models.Models",
    "OfferData": "com.ignite.model.offerData.OfferData",
    "User": "com.ignite.model.user.User",
    "Person": "com.ignite.model.person.Person",
    "Occupation": "com.ignite.model.occupation.Occupation",
    "Dependent": "com.ignite.model.dependent.Dependent",
    "Car": "com.ignite.model.car.Car"
}


separators = {
    "ID_SEPARATOR": "_",
    "ID_SUFFIX_SEPARATOR": "-"
}


collection_names_hint = {
    "com.ignite.model.person.Person": "person",
    "com.ignite.model.address.Address": "address",
    "com.ignite.model.models.Models": "models",
    "com.ignite.model.offerData.OfferData": "offerdata",
    "com.ignite.model.user.User": "user",
    "com.ignite.model.occupation.Occupation": "occupation",
    "com.ignite.model.dependent.Dependent": "dependent",
    "com.ignite.model.car.Car": "car"
}

class_merge_attributes_map = {
    "com.ignite.model.person.Person": [],
    "com.ignite.model.occupation.Occupation": [],
    "com.ignite.model.dependent.Dependent": [],
    "com.ignite.model.address.Address": [],
    "com.ignite.model.models.Models": [],
    "com.ignite.model.offerData.OfferData": [],
    "com.ignite.model.user.User": [],
    "com.ignite.model.car.Car": []
}
COLLECTIONS_INDEXES = {
    "person": [
        {
            "type": "SINGLE",
            "specifier": pymongo.ASCENDING,
            "index_name": "Id"
        }
    ],
    "car": [
        {
            "type": "SINGLE",
            "specifier": pymongo.ASCENDING,
            "index_name": "Id"
        }
    ]
}
