import sys
from datetime import datetime
import traceback
from pip._internal import main
main(['install','jsonpickle==2.2.0','--target','/tmp'])
sys.path.insert(0,'/tmp')
import jsonpickle
import utilities.constant as const
import utilities.log_utils as log_utils
from awsglue.context import GlueContext
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from utilities.ignite import process_ignite_feed as main_utils
from utilities.ignite import s3_utils_helper
from utilities.ignite.feed_runtime_context import FeedRuntimeContext, JobStatus

# Logging
logger = log_utils.get_logger()

args = {}
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'bucket', 'event_key','brand', 'country', 'feedfiles_list', 'type', 'env', 'x_correlation_id'])


x_correlation_id = args['x_correlation_id']

if ('test' in x_correlation_id.lower()):
    const.TEST = True

sc = SparkContext()
glueContext = GlueContext(sc.getOrCreate())
spark = glueContext.spark_session

feed_runtime_context = FeedRuntimeContext.get_instance()
feed_runtime_context.brand = args['brand']
feed_runtime_context.country = args['country']
feed_runtime_context.clientType = args['type']
feed_runtime_context.x_correlation_id = args['x_correlation_id']
feed_runtime_context.env = args['env']
feed_runtime_context.job_name = args['JOB_NAME']
feed_runtime_context.bucket = args['bucket']
feed_runtime_context.event_key = args['event_key']
feed_runtime_context.logger = logger
feed_runtime_context.spark = spark
feed_runtime_context.glueContext = glueContext

def main() :
    try:
        print(feed_runtime_context)
        date_time = datetime.now().strftime(const.S3_FILE_DATEPATTERN)[:-3]
        const.CURRENT_TIMESTAMP = date_time
        result = main_utils.process_ignite()
        if (result):
            log_utils.print_info_logs("ignite glue processing completed!!!")
            s3_utils_helper.move_s3_objects_to_processed()
                     
        else:
            # before moving file to reject on S3 check if brand-market supports
            # multiple feed file and job needed to be terminate in absense of
            # required feed files 
            if FeedRuntimeContext.get_instance().terminate_job_silently():
                log = "brand: '{}', market: '{}' configured to upload multiple "+ \
                      "feed files which are not avalible yet, terminating job run quitely"
                log =  log.format(feed_runtime_context.brand, feed_runtime_context.country)
                log_utils.print_info_logs(log)
                pass
            else:
                s3_utils_helper.move_s3_objects_to_reject()
    except Exception as e:
        traceback.print_exc()
        log_utils.print_error_logs('Error in Ignite glue job')
        log_utils.print_error_logs(str(e))

        if const.PRINT_EXCEPTION:
            feedRuntimeContext = FeedRuntimeContext.get_instance()
            feedRuntimeContext.jobStatus = JobStatus.FAILED
            feedRuntimeContext.stackTrace = ''.join(traceback.TracebackException.from_exception(e).format())

        # move s3 file to rejected folder
        if not const.TEST: 
            s3_utils_helper.move_s3_objects_to_reject() 
        raise e
          
try :
    main()
except Exception as e:
    log_utils.print_error_logs(str(e))
